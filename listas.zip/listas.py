def saudacao():
    # Imprime a saudação inicial
    print('Listas em Python - Jsandev')
    print('Git: https://github.com/jsandev2030')

def soma(v): # Função para a soma
    soman = 0
    for num in v:
        soman += num
    print('A soma dos números é:', int(soman))

def media(v): # Função para a média
    median = 0
    for num in v:
        median += num
    med = median/len(v)
    print('A média dos números é:', int(med))

def maximo(v): # Função para o máximo
    max_value = None
    for num in v:
        if (max_value is None or num > max_value):
            max_value = num
    print('O valor máximo é:', int(max_value))

def minimo(v): # Função para o mínimo
    min_value = None
    for num in v:
        if (min_value is None or num < min_value):
            min_value = num
    print('O valor mínimo é:', int(min_value))

def ordena(v): # Função para lista ordenada
    ordena_nums = sorted(v)
    print('A lista ordenada é:', ordena_nums)

def desordena(v): # Função para lista desordenada
    print('A lista desordenada é:', v)

def getNumbers():
    # Declara o array como vazio
    vals = []
    
    # Imprime a saudação
    saudacao()
    
    # Captura valores inseridos pelo utilizador
    valor = int(input("Digite um valor: "))
    
    # Adiciona esses valores num array
    vals.append(valor)
    
    # Captura até 5 valores inteiros para a lista
    for valor in range (0,4):
        # Inserindo o próximo valor
        valor = int(input("Digite um novo valor: "))
        
        # Dessa maneira, nós asseguramos que só valores > 0 serão aceitos
        if valor <= 0: 
            print('fim')
        else: vals.append(valor)
    
    # Imprime a soma da lista
    soma(vals)

    # Imprime a média da lista
    media(vals)

    # Imprime o valor máximo da lista
    maximo(vals)

    # Imprime o valor mínimo da lista
    minimo(vals)

    # Imprime a lista desordenada
    desordena(vals)

    # Imprime a lista ordenada
    ordena(vals)
    
# Captura e retorna uma lista com 5 inteiros
getNumbers()