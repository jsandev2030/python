# Importa das bibliotecas que precisamos para criar o gráfico e processar as informações
import matplotlib.pyplot as plt
import datetime
import csv

# Cria os arrays que irão guardar os dados do ficheiro CSV
x = []
y = []

# Defini um nome para o ficheiro a ser criado
e = datetime.datetime.now()
filename = ("pt-populacao-bar_%s%s%s%s%s%s" %(e.day, e.month, e.year, e.hour, e.minute, e.second))

# Importa os dados do ficheiro .csv e os armazena em arrays
with open('...caminho_absoluto_do_diretorio_do_ficheiro.../files/pt.csv','r') as csvfile:
    plots = csv.reader(csvfile, delimiter = ';')
    for row in plots:
        x.append(float(row[0]))
        y.append(float(row[1]))

# Cria o gráfico de barras com as respectivas legendas utilizando a biblioteca matplotlib
plt.bar(x, y, width=8, edgecolor="skyblue", linewidth=1, linestyle="-")
plt.title('População de Portugal segundo os Censos: total e por sexo')
plt.ylabel('População (casa dos milhões)')
plt.xlabel('10-10 Anos')

# Salva o gráfico em um ficheiro PDF com o nome que definimos anteriormente
plt.savefig("...caminho_absoluto_do_diretorio_do_para_armazenar_o_ficheiro.../files/"+filename+".pdf", dpi=300)

# Mostra o gráfico na tela
plt.show()
