# Percentage and interest calculator
# 
# Autor: Santiago Alves
# EMail: santiago.alves.work@outlook.com
#
