# Calculador de porcentagem e juros

# Pede o valor do produto
numero = float(input('Informe o valor:'))

# Pede o valor do desconto
porcent = float(input('Informe a porcentagem:'))

# Calcula a porcentagem do desconto
def calcPercDesc():
    perc = porcent / 100
    return perc

# Calcula o desconto
def calcDesc():
    desconto = numero * calcPercDesc()
    return desconto

# Subtrai o valor do desconto do valor do produto
def calcSubDesc():
    sub = numero - calcDesc()
    return sub

# soma o valor do desconto caso queira o valor em juros
def calcSumDesc():
    sum = numero + calcDesc()
    return sum

# Função que formata o valor de numero, conta1 e conta2 para euros
def fCurrency(float_currency):
    float_currency = "{:0,.2f}€".format(float_currency)
    return float_currency

# Função que formata o valor da porcentagem
def fPercent(percent_converion):
    percent_converion = f"{percent_converion:.1%}"
    return percent_converion

# Imprime valor do produto com desconto
print(fCurrency(numero), 'com', fPercent(calcPercDesc()), 'de desconto =', fCurrency(calcSubDesc()))

# Imprime valor do produto com juros
print(fCurrency(numero), 'com', fPercent(calcPercDesc()), 'de juros =', fCurrency(calcSumDesc()))
