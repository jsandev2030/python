# Plot Chart with MatPlotLib
# 
# Autor: Santiago Alves
# EMail: santiago.alves.work@outlook.com
#
